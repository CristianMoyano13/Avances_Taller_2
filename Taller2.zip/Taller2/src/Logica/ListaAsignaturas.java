package Logica;

import Dominio.Asignatura;
public class ListaAsignaturas {
	
		private int cont;
		private int max;
		private Asignatura[] ListaAsignaturas;
		
		public ListaAsignaturas(int max) {
			ListaAsignaturas = new Asignatura[max];
			cont = 0;
			this.max=max;
		}
		
		public boolean insertarAsignatura(Asignatura asignatura) { 
			if (cont < max) {
				ListaAsignaturas[cont] = asignatura;
				cont++;
				return true;

			} else {
				return false;
			}

		}
		
		public Asignatura buscarAsignatura(String codigo) {
			int i;
			for (i = 0; i < cont; i++) {
				if (ListaAsignaturas[i].getCodigoAsignatura().equals(codigo)) {
					break;
				}
			}
			if (i == cont) {
				return null;
			} 
			else {
				return ListaAsignaturas[i];
			}
		}
		
		public Asignatura getAsignaturaI(int i) {
			if (i >= 0 && i < cont) {
				return ListaAsignaturas[i];

			} else {
				return null;
			}

		}

		public int getCont() {
			return cont;
		}

		public void setCont(int cont) {
			this.cont = cont;
		}

		public int getMax() {
			return max;
		}

		public void setMax(int max) {
			this.max = max;
		}

		public Asignatura[] getListaAsignaturas() {
			return ListaAsignaturas;
		}

		public void setListaAsignaturas(Asignatura[] listaAsignaturas) {
			ListaAsignaturas = listaAsignaturas;
		}
		
}
