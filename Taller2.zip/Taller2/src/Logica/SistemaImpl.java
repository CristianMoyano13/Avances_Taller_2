package Logica;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import Dominio.Asignatura;
import Dominio.AsignaturaObligatoria;
import Dominio.AsignaturaOpcional;
import Dominio.Estudiante;
import Dominio.Paralelo;
import Dominio.Profesor;

public class SistemaImpl implements Sistema{
	private ListaAsignaturas ListaAsignaturas;
	private ListaEstudiantes ListaEstudiantes;
	private ListaParalelos ListaParalelos;
	private ListaProfesores ListaProfesores;
	
	public SistemaImpl() {
		ListaAsignaturas= new ListaAsignaturas(1000);
		ListaEstudiantes = new ListaEstudiantes(1000);
		ListaParalelos = new ListaParalelos(1000);
		ListaProfesores = new ListaProfesores(1000);
	}
	/**
	 * Este metodo agregar� un estudiante al sistema
	 */
	public boolean agregarEstudiante(String rutEstudiante, String correoEstudiante, int nivel,String contrase�aEstudiante) {
		Estudiante E = new Estudiante(rutEstudiante, correoEstudiante, nivel, contrase�aEstudiante);
		boolean ingreso = ListaEstudiantes.insertarEstudiante(E);
		return ingreso;
	}
	/**
	 * Este metodo agregar� una asignatura al sistema
	 */
	public boolean agregarAsignatura(String codigoAsignatura, String nombreAsignatura, int creditos,String tipoAsignatura) {
		Asignatura A = new Asignatura(codigoAsignatura,nombreAsignatura,creditos,tipoAsignatura);
		boolean ingreso = ListaAsignaturas.insertarAsignatura(A);
		return ingreso;
	}
	/**
	 * Este metodo agregar� un profesor al sistema
	 */
	public boolean agregarProfesor(String rutProfesor, String correoProfesor, String contrase�aProfesor, int salario) {
		Profesor P = new Profesor(rutProfesor,correoProfesor,contrase�aProfesor,salario);
		boolean ingreso = ListaProfesores.insertarProfesor(P);
		return ingreso;
	}
	/**
	 * Este metodo agregar� un paralelo al sistema
	 */
	public boolean agregarParalelo(int numeroParalelo, String codigoAsignatura, String rutProfesor) {
		Paralelo P = new Paralelo(numeroParalelo,codigoAsignatura,rutProfesor);
		boolean ingreso = ListaParalelos.insertarParalelo(P);
		return ingreso;
	}
	/**
	 * Este metodo asociar� el paralelo con la asignatura
	 */
	public void asociarParaleloAsignatura(int numeroParalelo, String codigoAsignatura) {
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		Paralelo P =ListaParalelos.buscarParalelo(numeroParalelo, codigoAsignatura);
		if (P != null && A !=null) {
			P.getListaParalelos().insertarParalelo(P);
		}
	}
	/**
	 * Este metodo asociar� el estudiante con la asignatura
	 */
	public void asociarEstudianteAsignaturaCursada(String rutEstudiante, String codigoAsignatura,double notafinal) {
		Estudiante E =ListaEstudiantes.buscarEstudiante(rutEstudiante);
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		if (E != null && A !=null) {
			E.getAsignaturas().insertarAsignatura(A);
		}
	}
	/**
	 * Este metodo asociar� el estudiante con la AsignaturaInscrita
	 */
	public void asociarEstudianteAsignaturaInscrita(String rutEstudiante, String codigoAsignatura,int paralelo) {
		Estudiante E =ListaEstudiantes.buscarEstudiante(rutEstudiante);
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		if (E != null && A !=null) {
			E.getAsignaturas().insertarAsignatura(A);
		}
	}

	/**
	 * Este metodo asociar� el profesor con la asignatura
	 */
	public void asociarProfesorAsignatura(String codigoAsignatura, String rutProfesor) {
		Profesor P =ListaProfesores.buscarProfesor(rutProfesor);
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		if (P != null && A !=null) {
			P.getAsignaturas().insertarAsignatura(A);
		}
		
	}
	/**
	 * verificar� si se encunetra el correo dentro del sistema
	 * @param correo
	 * @return falso si no se encuentra y verdadero si se encuentra
	 */
	public boolean verificarExistenciaCorreos(String correo) {
		Estudiante e = ListaEstudiantes.buscarEstudiante(correo);
		Profesor p = ListaProfesores.buscarProfesor(correo);
		if(e == null || p == null) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * Este m�todo iniciar� la sesion seg�n los datos entregados
	 */
	public void iniciar_sesion() { 
		boolean  llave = false;
		while(llave == false) {
			System.out.println("INICIAR SESION");
			System.out.println("Escriba su correo o su nombre de usuario de Administrador: ");
			Scanner sc = new Scanner(System.in);
			String correo = sc.nextLine();
			System.out.println("Escriba su contrase�a");
			String pass = sc.nextLine();
			
			if(verificarExistenciaCorreos(correo)) {
				for(int i=0;i<ListaEstudiantes.getCont();i++) {
					if(correo.equals(ListaEstudiantes.getEstudianteI(i).getCorreo()) && pass.equals(ListaEstudiantes.getEstudianteI(i).getContrase�a())) {
						llave = true;
						System.out.println("Menu Estudiante");
						MenuEstudiante();
					}
				}
				for(int i=0;i<ListaProfesores.getCont();i++) {
					if(correo.equals(ListaProfesores.getProfesorI(i).getCorreo()) && pass.equals(ListaProfesores.getProfesorI(i).getContrase�a())) {
						llave = true;
						System.out.println("Menu Profesor");
						MenuProfesor();
					}
				}
				if (correo.equals("Admin") && pass.equals("GHI_789")) {
					llave = true;
					//MenuAdministrador();
					System.out.println("Menu Administrador");
				}
				else {
					System.out.println("El correo o la contrase�a no es v�lida");
					System.out.println("Volver a Intentarlo (0) - Salir del Sistema (1)");
					int opcion = sc.nextInt();
					if(opcion == 0) {
						llave = false;
					}
					else {
						System.out.println("Saliendo del sistema...");
						llave = true;
					}
					
				}
			}
		}
	}
	/**
	 * 
	 * @param fechaActual
	 * @param fechaInicio
	 * @param fechaFin
	 * @return verdadero si se encuentra dentro del rango y falso si no se encuentra dentro del rango
	 */
	private boolean comprobarFechaRango(Date fechaActual,Date fechaInicio, Date fechaFin) {
		if(fechaActual.getTime() > fechaInicio.getTime() && fechaActual.getTime() < fechaFin.getTime()) {
			return true;
		}
		else {
			return false;
		}
	}
	/**
	 * Este m�todo iniciar� el men� seg�n la fecha que se ingrese
	 */
	private void MenuEstudiante() {
		Date fechaInicioSemestre = new Date(8/05/2021);
		Date fechaFinInicioSemestre = new Date(02/05/2021);
		Date fechaInicioMitadSemestre = new Date(03/05/2021);
		Date fechaFinMitadSemestre = new Date(11/07/2021);
		Date fechaCierreSemestre = new Date(26/07/2021);
		System.out.println("Introduzca la fecha con formato (dd/mm/yyyy):");
        Scanner sc = new Scanner(System.in);
        String fecha = sc.nextLine();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaActual = null;
        String date = fecha;
        try{
            fechaActual = df.parse(date);
            System.out.println("Ahora hemos creado un objeto date con la fecha indicada, "+fechaActual);
            if (comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaFinInicioSemestre) == true) {
            	MenuInicioSemestreAlumno();
            }
            else if(comprobarFechaRango(fechaActual,fechaInicioMitadSemestre,fechaFinMitadSemestre) == true) {
            	MenuMitadSemestreAlumno();
            }
            else if(comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaCierreSemestre) == false) {
			System.out.println("No hay acciones disponibles");
            }
            else if (fechaActual.getTime()>fechaCierreSemestre.getTime()) {
			System.out.println("Disfrute sus vacaciones");
            }
        } 
        catch (Exception e){ 
        	System.out.println("Formato inv�lido");
    	}
        if (!df.format(fechaActual).equals(date)){
            System.out.println("Fecha inv�lida!!");
        } 
        else {
            System.out.println("Fecha valida");
        }

    }
	/**
	 * Este m�todo iniciar� el men� seg�n la fecha que se ingrese
	 */
	private void MenuProfesor() {
		Date fechaInicioSemestre = new Date(8/05/2021);
		Date fechaFinInicioSemestre = new Date(2/05/2021);
		Date fechaInicioFinSemestre = new Date(12/07/2021);
		Date fechaFinalFinSemestre = new Date(25/07/2021);
		Date fechaCierreSemestre = new Date(26/07/2021);
		System.out.println("Introduzca la fecha con formato dd/mm/yyyy");
        Scanner sc = new Scanner(System.in);
        String fecha = sc.nextLine();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaActual = null;
        String date = fecha;
        try{
            fechaActual = df.parse(date);
            if (comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaFinInicioSemestre) == true) {
			//MenuInicioSemestreProfesor(); Este es el chequeo de alumnos del RF4
            }
            else if(comprobarFechaRango(fechaActual,fechaInicioFinSemestre,fechaFinalFinSemestre) == true) {
			MenuFinalSemestreProfesor();
            }
            else if(comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaCierreSemestre) == false) {
            	System.out.println("No hat acciones disponibles");
            }
            else if (fechaActual.getTime()>fechaCierreSemestre.getTime()) {
            	System.out.println("Disfrute sus vacaciones");
            }
        }
        catch (Exception e){ 
        	System.out.println("Formato inv�lido");
    	}
        if (!df.format(fechaActual).equals(date)){
            System.out.println("Fecha inv�lida!!");
        } 
        else {
            System.out.println("Fecha v�lida");
        }
    }
	/**
	 * Este m�todo iniciar� el men� de inicio del semestre del alumno
	 */
	public void MenuInicioSemestreAlumno() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Inscribir asignatura Alumno (0) - Eliminar asignatura Alumno (1): ");
		int opcion = sc.nextInt();
		boolean llave = false;
		while(llave=false) {
			if (opcion == 0) {
				llave = true;
				System.out.println("Incribir asignatura");
				System.out.println("Que asignatura desea inscribir?: ");
				String asignatura = sc.nextLine();
				if(verificarExistenciaAsignatura(asignatura)) {
					for(int i=0;i<ListaAsignaturas.getCont();i++) {
						Asignatura a = ListaAsignaturas.getAsignaturaI(i);
						if(a instanceof AsignaturaObligatoria) {
							AsignaturaObligatoria AO = (AsignaturaObligatoria)a;
							System.out.println("Su nivel es: " +AO.getNivel());
							if (ListaEstudiantes.getEstudianteI(i).getNivel() == AO.getNivel()) {
								for(int j=0;j<ListaParalelos.getCont();j++) {
									if (ListaAsignaturas.getAsignaturaI(j).getCodigo().equals(ListaParalelos.getParaleloI(j).getCodigoAsignatura())){
										System.out.println("C"+ListaParalelos.getParaleloI(j).getNumeroParalelo());
									}
								}
								System.out.println("Que paralelo desea inscribir?(Ingrese el n�mero del paralelo): ");
								int numeroParalelo = sc.nextInt();
								if(verificarExistenciaParalelo(numeroParalelo,ListaAsignaturas.getAsignaturaI(i).getCodigo())) {
									System.out.println("Inscribiendo Asignatura");
									ListaEstudiantes.getEstudianteI(i).getAsignaturas().insertarAsignatura(AO);
									ListaEstudiantes.getEstudianteI(i).setAsignaturas(ListaAsignaturas);
								}
								else {
									System.out.println("El paralelo no existe");
								}
							}
							else {
								System.out.println("No cumple con los Pre-Requisitos");
							}	
						}
						else if(a instanceof AsignaturaOpcional) {
							AsignaturaOpcional AOP = (AsignaturaOpcional)a;
							if (ListaAsignaturas.getAsignaturaI(i).getCodigo().equals(ListaParalelos.getParaleloI(i).getCodigoAsignatura())){
								System.out.println("Que paralelo desea inscribir?(Ingrese el n�mero del paralelo): ");
								int numeroParalelo = sc.nextInt();
								if(verificarExistenciaParalelo(numeroParalelo,ListaAsignaturas.getAsignaturaI(i).getCodigo())) {
									System.out.println("Inscribiendo Asignatura");
									ListaEstudiantes.getEstudianteI(i).getAsignaturas().insertarAsignatura(AOP);
								}
								else {
									System.out.println("El paralelo no existe");
								}
							}
						}
					}
				}
				else{
					System.out.println("No tienes esa asignatura");
				}
				sc.close();
			}
			else if(opcion == 1) {
				llave = true;
				System.out.println("Eliminar asignatura Alumno:");
				for(int i=0;i<ListaEstudiantes.getEstudianteI(0).getAsignaturas().getCont();i++) {
					System.out.println(ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getNombre()+ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getCodigo());
				}
				System.out.println("Que asignatura desea eliminar?: ");
				String asignatura = sc.nextLine();
				if(verificarExistenciaAsignatura(asignatura)) {
					ListaEstudiantes.getEstudianteI(0).getAsignaturas().eliminar(ListaEstudiantes.getEstudianteI(0).getAsignaturas().buscarPosicion(asignatura));
					System.out.println("Eliminando asignatura");
				}
				else {
					System.out.println("No tienes esa asignatura");
				}
				sc.close();
			}
			else {
				llave = false;
				System.out.println("Comando invalido");
			}
		}
	}
	/**
	 * Este m�todo iniciar� el men� de mitad del semestre del alumno
	 */
	public void MenuMitadSemestreAlumno() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Eliminar asignatura Alumno:");
		for(int i=0;i<ListaEstudiantes.getEstudianteI(0).getAsignaturas().getCont();i++) {
			System.out.println(ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getNombre()+ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getCodigo());
		}
		System.out.println("Que asignatura desea eliminar?: ");
		String asignatura = sc.nextLine();
		if(verificarExistenciaAsignatura(asignatura)) {
			ListaEstudiantes.getEstudianteI(0).getAsignaturas().eliminar(ListaEstudiantes.getEstudianteI(0).getAsignaturas().buscarPosicion(asignatura));
			System.out.println("Eliminando asignatura");
		}
		else {
			System.out.println("No tienes esa asignatura");
		}
		sc.close();
	}
	/**
	 * Este m�todo iniciar� el men� del final  del semestre del profesor
	 */
	public void MenuFinalSemestreProfesor() {
		System.out.println("ingresar nota final:");
		for(int i=0;i<ListaProfesores.getProfesorI(0).getAsignaturas().getCont();i++) {
			System.out.println(ListaProfesores.getProfesorI(0).getAsignaturas().getAsignaturaI(i).getNombre()+ListaProfesores.getProfesorI(0).getAsignaturas().getAsignaturaI(i).getCodigo());
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("Que asignatura desea ingresar notas: ");
		String asignatura = sc.nextLine();
		if(verificarExistenciaAsignatura(asignatura)) {
			ListaParalelos.getParaleloI(0).getCodigoAsignatura();
			System.out.println("rut estudiante a colocar nota final: ");
			String nombre = sc.nextLine();
			if(verificarExistenciaAlumno(nombre)) {
				
			}
		}
		else {
			System.out.println("No dicta esa asignatura o no existe");
		}
		sc.close();
	}
	/**
	 * Este m�todo iniciar� el men� de administrador del cierre de semestre 
	 */
	public void cierre_semestre() {
		
	}
	/**
	 * Esta funcion verificar� la existencia de una asignatura
	 * @param nombre
	 * @return falso si no se encuentra y verdadero si se encuentra
	 */
	public boolean verificarExistenciaAsignatura(String nombre) {
		Asignatura nuevo = ListaAsignaturas.buscarAsignatura(nombre);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * Esta funcion verificar� la existencia de un alumno
	 * @param nombre
	 * @return falso si no se encuentra y verdadero si se encuentra
	 */
	public boolean verificarExistenciaAlumno(String nombre) {
		Estudiante nuevo = ListaEstudiantes.buscarEstudiante(nombre);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * Esta funcion verificar� la existencia de un paralelo
	 * @param nombre
	 * @return falso si no se encuentra y verdadero si se encuentra
	 */
	public boolean verificarExistenciaParalelo(int numeroParalelo,String codigoAsignatura) {
		Paralelo p = ListaParalelos.buscarParalelo(numeroParalelo, codigoAsignatura);
		if(p==null) {
			return false;
		}
		else {
			return true;
		}
	}
	

}
