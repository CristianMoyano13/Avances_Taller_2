package Logica;

public class SistemaImpl implements Sistema{

	@Override
	public boolean agregarEstudiante(String rutEstudiante, String correoEstudiante, int nivel,
			String contrase�aEstudiante) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean agregarAsignatura(String codigoAsignatura, String nombreAsignatura, int creditos,
			String tipoAsignatura) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean ingresarProfesor(String rutProfesor, String correoProfesor, String contrase�aProfesor,
			String contrase�aProfesor2, int salario) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean ingresarParalelo(int numeroParalelo, String codigoAsignatura, String rutProfesor) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void asociarParaleloAsignatura(int numeroParalelo, String codigoAsignatura) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void asociarEstudianteAsignatura(String rutEstudiante, String codigoAsignatura) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void asociarProfesorAsignatura(String codigoAsignatura, String rutProfesor) {
		// TODO Auto-generated method stub
		
	}

}
