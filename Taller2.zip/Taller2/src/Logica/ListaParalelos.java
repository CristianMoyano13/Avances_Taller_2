package Logica;

import Dominio.Paralelo;
public class ListaParalelos {
		private int cont;
		private int max;
		private Paralelo[] ListaParalelos;
		
		public ListaParalelos(int max) {
			ListaParalelos = new Paralelo[max];
			cont = 0;
			this.max=max;
		}
		public boolean insertarParalelo(Paralelo paralelo) { 
			if (cont < max) {
				ListaParalelos[cont] = paralelo;
				cont++;
				return true;
			} else {
				return false;
			}
		}
		public Paralelo buscarParalelo(int numero, String codigoAsignatura) {
			int i;
			for (i = 0; i < cont; i++) {
				if (ListaParalelos[i].getCodigoAsignatura().equals(codigoAsignatura) && ListaParalelos[i].getNumeroParalelo() == numero) {
					break;
				}
			}
			if (i == cont) {
				return null;
			} 
			else {
				return ListaParalelos[i];
			}
		}
		
		public Paralelo getParaleloI(int i) {
			if (i >= 0 && i < cont) {
				return ListaParalelos[i];

			} else {
				return null;
			}
		}

		public int getCont() {
			return cont;
		}

		public void setCont(int cont) {
			this.cont = cont;
		}

		public int getMax() {
			return max;
		}

		public void setMax(int max) {
			this.max = max;
		}
		public Paralelo[] getListaParalelos() {
			return ListaParalelos;
		}
		public void setListaParalelos(Paralelo[] listaParalelos) {
			ListaParalelos = listaParalelos;
		}
}
