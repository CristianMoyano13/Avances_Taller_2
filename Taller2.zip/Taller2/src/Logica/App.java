package Logica;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class App {
	public static void main(String[] args) throws NumberFormatException, IOException {
	Sistema sistema = (Sistema) new SistemaImpl();
	Carga_Estudiantes(sistema);
	Carga_Asignaturas(sistema);
	Carga_Profesores(sistema);
	Carga_Paralelos(sistema);
	Guardar_Estudiantes(sistema);
	Guardar_Asignaturas(sistema);
	Guardar_Profesores(sistema);
	Guardar_Paralelos(sistema);
	}
	
	private static void Carga_Estudiantes(Sistema sistema) throws NumberFormatException, IOException {
		File archivo = new File ("src/Estudiantes.txt"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String rutEstudiante = partes[0];
			String correoEstudiante = partes[1];
			int nivel = Integer.parseInt(partes[2]);
			String contrase�aEstudiante = partes[3];
			sistema.agregarEstudiante(rutEstudiante,correoEstudiante,nivel,contrase�aEstudiante);
			int AsignaturasCursadas = Integer.parseInt(partes[4]);
			int pos = 5;
			for(int i=0;i<AsignaturasCursadas;i++) {
				String codigoAsignatura = partes[pos++];
				int notaFinal = Integer.parseInt(partes[pos++]);
				sistema.asociarEstudianteAsignatura(rutEstudiante,codigoAsignatura);
				}
			int AsignaturasInscritas = Integer.parseInt(partes[8]);
			int pos2 = 9;
			for(int i=0;i<AsignaturasCursadas;i++) {
				String codigoAsignatura = partes[pos2++];
				int notaFinal = Integer.parseInt(partes[pos2++]);
				sistema.asociarEstudianteAsignatura(rutEstudiante,codigoAsignatura);
				}
			;
			}
		reader.close();
	}
	
	private static void Carga_Asignaturas(Sistema sistema) throws NumberFormatException, IOException {
		File archivo = new File ("src/Asignaturas.txt"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String codigoAsignatura= partes[0];
			String nombreAsignatura = partes[1];
			int creditos = Integer.parseInt(partes[2]);
			String tipoAsignatura = partes[3];
			sistema.agregarAsignatura(codigoAsignatura,nombreAsignatura,creditos,tipoAsignatura);
			if (tipoAsignatura.equals("obligatoria")) {
				int nivelAsignaturaO = Integer.parseInt(partes[5]);	
				int AsignaturasPreRequisitos = Integer.parseInt(partes[5]);	
				int pos = 6;
				for(int i=0;i<AsignaturasPreRequisitos;i++) {
					String codigoAsignaturaPreRequisitos = partes[pos++];
					}
			}
			else {
				int creditosPreRequisitos = Integer.parseInt(partes[8]);
			}
		}
		reader.close();
	}
	
	private static void Carga_Profesores(Sistema sistema) throws IOException {
		File archivo = new File ("src/Profesores.txt"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String rutProfesor = partes[0];
			String correoProfesor = partes[1];
			String contrase�aProfesor = partes[2];
			int salario = Integer.parseInt(partes[3]);
			sistema.ingresarProfesor(rutProfesor,correoProfesor,contrase�aProfesor,contrase�aProfesor,salario);     
		}
		reader.close();	
	}
	
	private static void Carga_Paralelos(Sistema sistema) throws IOException {
		File archivo = new File ("src/Paralelos.txt"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			int numeroParalelo = Integer.parseInt(partes[0]);
			String codigoAsignatura = partes[1];
			String rutProfesor = partes[2];
			sistema.ingresarParalelo(numeroParalelo,codigoAsignatura,rutProfesor);   
			sistema.asociarParaleloAsignatura(numeroParalelo,codigoAsignatura);
			sistema.asociarProfesorAsignatura(codigoAsignatura,rutProfesor);
		}
		reader.close();
	}
	private static void Guardar_Estudiantes(Sistema sistema){
	}
	private static void Guardar_Asignaturas(Sistema sistema){
	}
	private static void Guardar_Profesores(Sistema sistema){
	}
	private static void Guardar_Paralelos(Sistema sistema){
	}
	
}
