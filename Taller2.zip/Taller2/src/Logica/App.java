package Logica;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class App {
	public static void main(String[] args) throws NumberFormatException, IOException {
	Sistema sistema = (Sistema) new SistemaImpl();
	Carga_Asignaturas(sistema);
	Carga_Estudiantes(sistema);
	Carga_Profesores(sistema);
	Carga_Paralelos(sistema);
	Guardar_Estudiantes(sistema);
	Guardar_Asignaturas(sistema);
	Guardar_Profesores(sistema);
	Guardar_Paralelos(sistema);
	sistema.iniciar_sesion();
	}
	private static void Carga_Asignaturas(Sistema sistema) throws NumberFormatException, IOException {
		File archivo = new File ("src/Asignaturas"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String codigo= partes[0];
			String nombre = partes[1];
			int creditos = Integer.parseInt(partes[2]);
			String tipo = partes[3];
			sistema.agregarAsignatura(codigo,nombre,creditos,tipo);
			if (tipo.equals("obligatoria")) {
				String nivelAsignaturaO = partes[4];	
				int AsignaturasPreRequisitos = Integer.parseInt(partes[5]);	
				for(int i=0;i<AsignaturasPreRequisitos;i++) {
					String codigoAsignaturaPreRequisitos = partes[i];
					}
			}
			else {
				int creditospre = Integer.parseInt(partes[4]);
			}
		}
		reader.close();
	}
	private static void Carga_Profesores(Sistema sistema) throws IOException {
		File archivo = new File ("src/Profesores"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String rut = partes[0];
			String correo= partes[1];
			String contrase�a = partes[2];
			int salario = Integer.parseInt(partes[3]);
			sistema.agregarProfesor(rut,correo,contrase�a,salario);     
		}
		reader.close();	
	}
	private static void Carga_Paralelos(Sistema sistema) throws IOException {
		File archivo = new File ("src/Paralelos"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			int numeroParalelo = Integer.parseInt(partes[0]);
			String codigo = partes[1];
			String rut = partes[2];
			sistema.agregarParalelo(numeroParalelo,codigo,rut);   
			sistema.asociarParaleloAsignatura(numeroParalelo,codigo);
			sistema.asociarProfesorAsignatura(codigo,rut);
		}
		reader.close();
	}
	
	
	private static void Carga_Estudiantes(Sistema sistema) throws NumberFormatException, IOException {
		File archivo = new File ("src/Estudiantes"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String rut = partes[0];
			String correo = partes[1];
			int nivel = Integer.parseInt(partes[2]);
			String contrase�a = partes[3];
			sistema.agregarEstudiante(rut,correo,nivel,contrase�a);
			int AsignaturasCursadas = Integer.parseInt(partes[4]);
			for(int i=0;i<AsignaturasCursadas;i++) {
				String codigoAsignatura = partes[5];
				double notaFinal = Double.parseDouble(partes[6]);
				sistema.asociarEstudianteAsignaturaCursada(rut,codigoAsignatura,notaFinal);
			}
			int AsignaturasInscritas = Integer.parseInt(partes[7]);
			for(int i=0;i<=AsignaturasInscritas;i++) {
				String codigoAsignatura = partes[8];
				int numeroparalelo = Integer.parseInt(partes[9]);
				sistema.asociarEstudianteAsignaturaInscrita(rut,codigoAsignatura,numeroparalelo);
			}
		}
		reader.close();
	}
	
	private static void Guardar_Estudiantes(Sistema sistema){
	}
	private static void Guardar_Asignaturas(Sistema sistema){
	}
	private static void Guardar_Profesores(Sistema sistema){
	}
	private static void Guardar_Paralelos(Sistema sistema){
	}
	
}
