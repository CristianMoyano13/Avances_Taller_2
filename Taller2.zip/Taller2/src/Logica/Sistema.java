package Logica;

public interface Sistema {

	boolean agregarEstudiante(String rutEstudiante, String correoEstudiante, int nivel,String contrase�aEstudiante);
	boolean agregarAsignatura(String codigoAsignatura, String nombreAsignatura, int creditos,String tipoAsignatura);
	boolean ingresarProfesor(String rutProfesor, String correoProfesor, String contrase�aProfesor,String contrase�aProfesor2, int salario);
	boolean ingresarParalelo(int numeroParalelo, String codigoAsignatura, String rutProfesor);
	void asociarParaleloAsignatura(int numeroParalelo, String codigoAsignatura);
	void asociarEstudianteAsignatura(String rutEstudiante, String codigoAsignatura);
	void asociarProfesorAsignatura(String codigoAsignatura, String rutProfesor);
}
