package Dominio;

import Logica.ListaAsignaturas;
import Logica.ListaParalelos;

public class Paralelo {
	private int numeroParalelo;
	private String codigoAsignatura;
	private String rutProfesor;
	public ListaParalelos paralelos;
	
	public Paralelo(int numeroParalelo, String codigoAsignatura, String rutProfesor) {
		this.numeroParalelo = numeroParalelo;
		this.codigoAsignatura = codigoAsignatura;
		this.rutProfesor = rutProfesor;
	}
	public int getNumeroParalelo() {
		return numeroParalelo;
	}
	public void setNumeroParalelo(int numeroParalelo) {
		this.numeroParalelo = numeroParalelo;
	}
	public String getCodigoAsignatura() {
		return codigoAsignatura;
	}
	public void setCodigoAsignatura(String codigoAsignatura) {
		this.codigoAsignatura = codigoAsignatura;
	}
	public String getRutProfesor() {
		return rutProfesor;
	}
	public void setRutProfesor(String rutProfesor) {
		this.rutProfesor = rutProfesor;
	}
	public ListaParalelos getListaParalelos() {
		return paralelos;
	}
	public void setListaParalelos(ListaParalelos paralelos) {
		this.paralelos = paralelos;
	}
}
