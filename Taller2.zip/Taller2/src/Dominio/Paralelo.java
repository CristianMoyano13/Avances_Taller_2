package Dominio;

public class Paralelo {
	private String numeroParalelo;
	private String codigoAsignatura;
	private String rutProfesor;
	public Paralelo(String numeroParalelo, String codigoAsignatura, String rutProfesor) {
		this.numeroParalelo = numeroParalelo;
		this.codigoAsignatura = codigoAsignatura;
		this.rutProfesor = rutProfesor;
	}
	public String getNumeroParalelo() {
		return numeroParalelo;
	}
	public void setNumeroParalelo(String numeroParalelo) {
		this.numeroParalelo = numeroParalelo;
	}
	public String getCodigoAsignatura() {
		return codigoAsignatura;
	}
	public void setCodigoAsignatura(String codigoAsignatura) {
		this.codigoAsignatura = codigoAsignatura;
	}
	public String getRutProfesor() {
		return rutProfesor;
	}
	public void setRutProfesor(String rutProfesor) {
		this.rutProfesor = rutProfesor;
	}
	
	
	
}
