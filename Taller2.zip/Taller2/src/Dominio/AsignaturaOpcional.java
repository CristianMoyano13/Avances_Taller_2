package Dominio;

public class AsignaturaOpcional extends Asignatura {
	private int creditosMinimos;

	public AsignaturaOpcional(String codigoAsignatura, String nombreAsignatura, int creditos, String tipo,int creditosMinimos) {
		super(codigoAsignatura, nombreAsignatura, creditos, tipo);
		this.creditosMinimos = creditosMinimos;
	}

	public int getCreditosMinimos() {
		return creditosMinimos;
	}

	public void setCreditosMinimos(int creditosMinimos) {
		this.creditosMinimos = creditosMinimos;
	}
	

	
}
