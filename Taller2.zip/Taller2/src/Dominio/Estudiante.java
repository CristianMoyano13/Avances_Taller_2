package Dominio;

public class Estudiante {
	private String rutEstudiante;
	private String correoEstudiante;
	private int nivelEstudiante;
	private String contrase�aEstudiante;
	
	public Estudiante(String rutEstudiante, String correoEstudiante, int nivelEstudiante,String contrase�aEstudiante) {
		this.rutEstudiante = rutEstudiante;
		this.correoEstudiante = correoEstudiante;
		this.nivelEstudiante = nivelEstudiante;
		this.contrase�aEstudiante = contrase�aEstudiante;
	}
	public String getRutEstudiante() {
		return rutEstudiante;
	}
	public void setRutEstudiante(String nombreEstudiante) {
		this.rutEstudiante = nombreEstudiante;
	}
	public String getCorreoEstudiante() {
		return correoEstudiante;
	}
	public void setCorreoEstudiante(String correoEstudiante) {
		this.correoEstudiante = correoEstudiante;
	}
	public int getNivelEstudiante() {
		return nivelEstudiante;
	}
	public void setNivelEstudiante(int nivelEstudiante) {
		this.nivelEstudiante = nivelEstudiante;
	}
	public String getContrase�aEstudiante() {
		return contrase�aEstudiante;
	}
	public void setContrase�aEstudiante(String contrase�aEstudiante) {
		this.contrase�aEstudiante = contrase�aEstudiante;
	}
	
	
	
}

