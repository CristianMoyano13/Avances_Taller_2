package Dominio;

public class AsignaturaObligatoria extends Asignatura {
	private int nivelAsignatura;
	private String preRequisitos;
	private String codigoPreRequisito;
	public AsignaturaObligatoria(String codigoAsignatura, String nombreAsignatura, int creditos, String tipo,int nivelAsignatura, String preRequisitos, String codigoPreRequisito) {
		super(codigoAsignatura, nombreAsignatura, creditos, tipo);
		this.nivelAsignatura = nivelAsignatura;
		this.preRequisitos = preRequisitos;
		this.codigoPreRequisito = codigoPreRequisito;
	}
	
	public int getNivelAsignatura() {
		return nivelAsignatura;
	}
	
	public void setNivelAsignatura(int nivelAsignatura) {
		this.nivelAsignatura = nivelAsignatura;
	}
	
	public String getPreRequisitos() {
		return preRequisitos;
	}
	
	public void setPreRequisitos(String preRequisitos) {
		this.preRequisitos = preRequisitos;
	}
	
	public String getCodigoPreRequisito() {
		return codigoPreRequisito;
	}
	
	public void setCodigoPreRequisito(String codigoPreRequisito) {
		this.codigoPreRequisito = codigoPreRequisito;
	}
	
	
}
