package Logica;

import Dominio.Estudiante;

public class ListaEstudiantes {
	private int cont;
	private int max;
	private Estudiante[] ListaEstudiantes;
	
	public ListaEstudiantes(int max) {
		ListaEstudiantes = new Estudiante[max];
		cont = 0;
		this.max=max;
	}
	
	public boolean insertarEstudiante(Estudiante estudiante) { 
		if (cont < max) {
			ListaEstudiantes[cont] = estudiante;
			cont++;
			return true;

		} else {
			return false;
		}

	}
	
	public Estudiante buscarEstudiante(String nombre) {
		int i;
		for (i = 0; i < cont; i++) {
			if (ListaEstudiantes[i].getRut().equals(nombre)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} 
		else {
			return ListaEstudiantes[i];
		}
	}
	
	public Estudiante getEstudianteI(int i) {
		if (i >= 0 && i < cont) {
			return ListaEstudiantes[i];

		} else {
			return null;
		}

	}

	public int getCont() {
		return cont;
	}

	public void setCont(int cont) {
		this.cont = cont;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public Estudiante[] getListaEstudiantes() {
		return ListaEstudiantes;
	}

	public void setListaEstudiantes(Estudiante[] listaEstudiantes) {
		ListaEstudiantes = listaEstudiantes;
	}
	
	

}
