package Logica;

import Dominio.Profesor;
public class ListaProfesores {
	private int cont;
	private int max;
	private Profesor[] ListaProfesores;
	
	public ListaProfesores(int max) {
		ListaProfesores = new Profesor[max];
		cont = 0;
		this.max=max;
	}
	
	public boolean insertarProfesor(Profesor profesor) { 
		if (cont < max) {
			ListaProfesores[cont] = profesor;
			cont++;
			return true;

		} else {
			return false;
		}

	}
	
	public Profesor buscarProfesor(String rut) {
		int i;
		for (i = 0; i < cont; i++) {
			if (ListaProfesores[i].getRut().equals(rut)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} 
		else {
			return ListaProfesores[i];
		}
	}
	
	public Profesor getProfesorI(int i) {
		if (i >= 0 && i < cont) {
			return ListaProfesores[i];

		} else {
			return null;
		}

	}

	public int getCont() {
		return cont;
	}

	public void setCont(int cont) {
		this.cont = cont;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public Profesor[] getListaProfesores() {
		return ListaProfesores;
	}

	public void setListaProfesores(Profesor[] listaProfesores) {
		ListaProfesores = listaProfesores;
	}
	
		

}
