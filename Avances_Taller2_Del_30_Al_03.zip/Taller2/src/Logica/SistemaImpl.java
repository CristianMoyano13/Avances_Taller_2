package Logica;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import Dominio.Asignatura;
import Dominio.AsignaturaObligatoria;
import Dominio.AsignaturaOpcional;
import Dominio.Estudiante;
import Dominio.Paralelo;
import Dominio.Profesor;

public class SistemaImpl implements Sistema{
	private ListaAsignaturas ListaAsignaturas;
	private ListaEstudiantes ListaEstudiantes;
	private ListaParalelos ListaParalelos;
	private ListaProfesores ListaProfesores;
	
	public SistemaImpl() {
		ListaAsignaturas= new ListaAsignaturas(1000);
		ListaEstudiantes = new ListaEstudiantes(1000);
		ListaParalelos = new ListaParalelos(1000);
		ListaProfesores = new ListaProfesores(1000);
	}
	
	@Override
	public boolean agregarEstudiante(String rutEstudiante, String correoEstudiante, int nivel,String contrase�aEstudiante) {
		Estudiante E = new Estudiante(rutEstudiante, correoEstudiante, nivel, contrase�aEstudiante);
		boolean ingreso = ListaEstudiantes.insertarEstudiante(E);
		return ingreso;
	}

	@Override
	public boolean agregarAsignatura(String codigoAsignatura, String nombreAsignatura, int creditos,String tipoAsignatura) {
		Asignatura A = new Asignatura(codigoAsignatura,nombreAsignatura,creditos,tipoAsignatura);
		boolean ingreso = ListaAsignaturas.insertarAsignatura(A);
		return ingreso;
	}

	@Override
	public boolean agregarProfesor(String rutProfesor, String correoProfesor, String contrase�aProfesor, int salario) {
		Profesor P = new Profesor(rutProfesor,correoProfesor,contrase�aProfesor,salario);
		boolean ingreso = ListaProfesores.insertarProfesor(P);
		return ingreso;
	}
	public boolean agregarParalelo(int numeroParalelo, String codigoAsignatura, String rutProfesor) {
		Paralelo P = new Paralelo(numeroParalelo,codigoAsignatura,rutProfesor);
		boolean ingreso = ListaParalelos.insertarParalelo(P);
		return ingreso;
	}
	public void asociarParaleloAsignatura(int numeroParalelo, String codigoAsignatura) {
		/*Paralelo P =ListaParalelos.buscarParalelo(numeroParalelo, codigoAsignatura);
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		if (P != null && A !=null) {
			P.getParalelos.insertarParalelo(A);
		}*/
	}
	public void asociarEstudianteAsignaturaCursada(String rutEstudiante, String codigoAsignatura,double notafinal) {
		Estudiante E =ListaEstudiantes.buscarEstudiante(rutEstudiante);
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		if (E != null && A !=null) {
			E.getAsignaturas().insertarAsignatura(A);
		}
	}
	public void asociarEstudianteAsignaturaInscrita(String rutEstudiante, String codigoAsignatura,int paralelo) {
		Estudiante E =ListaEstudiantes.buscarEstudiante(rutEstudiante);
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		if (E != null && A !=null) {
			E.getAsignaturas().insertarAsignatura(A);
		}
	}

	@Override
	public void asociarProfesorAsignatura(String codigoAsignatura, String rutProfesor) {
		Profesor P =ListaProfesores.buscarProfesor(rutProfesor);
		Asignatura A =ListaAsignaturas.buscarAsignatura(codigoAsignatura);
		if (P != null && A !=null) {
			P.getAsignaturas().insertarAsignatura(A);
		}
		
	}
	/////////////////////////////////////////////////////////////////////////////////
	public boolean verificarExistenciaCorreos(String correo) {
		Estudiante e = ListaEstudiantes.buscarEstudiante(correo);
		Profesor p = ListaProfesores.buscarProfesor(correo);
		if(e == null || p == null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void iniciar_sesion() { 
		boolean  llave = false;
		while(llave == false) {
			System.out.println("INICIAR SESION");
			System.out.println("Escriba su correo o su nombre de usuario de Administrador: ");
			Scanner sc = new Scanner(System.in);
			String correo = sc.nextLine();
			System.out.println("Escriba su contrase�a");
			String pass = sc.nextLine();
			
			if(verificarExistenciaCorreos(correo)) {
				for(int i=0;i<ListaEstudiantes.getCont();i++) {
					if(correo.equals(ListaEstudiantes.getEstudianteI(i).getCorreo()) && pass.equals(ListaEstudiantes.getEstudianteI(i).getContrase�a())) {
						llave = true;
						System.out.println("Menu Estudiante");
						MenuEstudiante();
					}
				}
				for(int i=0;i<ListaProfesores.getCont();i++) {
					if(correo.equals(ListaProfesores.getProfesorI(i).getCorreo()) && pass.equals(ListaProfesores.getProfesorI(i).getContrase�a())) {
						llave = true;
						System.out.println("Menu Profesor");
						MenuProfesor();
					}
				}
				if (correo.equals("Admin") && pass.equals("GHI_789")) {
					llave = true;
					///MenuAdministrador();
					System.out.println("Menu Administrador");
				}
				else {
					System.out.println("El correo o la contrase�a no es v�lida");
					System.out.println("Volver a Intentarlo (0) - Salir del Sistema (1)");
					int opcion = sc.nextInt();
					if(opcion == 0) {
						llave = false;
					}
					else {
						System.out.println("Saliendo del sistema...");
						llave = true;
					}
					
				}
			}
		}
	}
		
	private boolean comprobarFechaRango(Date fechaActual,Date fechaInicio, Date fechaFin) {
		if(fechaActual.getTime() > fechaInicio.getTime() && fechaActual.getTime() < fechaFin.getTime()) {
			return true;
		}
		else {
			return false;
		}
	}
	private void MenuEstudiante() {
		SimpleDateFormat fecha = new SimpleDateFormat("dd/MM/YYY");
		System.out.println("Ingrese la fecha actual (dd/MM/YYY): ");
		Date fechaActual = new Date(0);
		System.out.println("La fecha actual es: "+fecha.format(fechaActual));
		Date fechaInicioSemestre = new Date(8/05/2021);
		Date fechaFinInicioSemestre = new Date(02/05/2021);
		Date fechaInicioMitadSemestre = new Date(03/05/2021);
		Date fechaFinMitadSemestre = new Date(11/07/2021);
		Date fechaCierreSemestre = new Date(26/07/2021);
		
		if (comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaFinInicioSemestre) == true) {
			//MenuInicioSemestreAlumno();
			
		}
		else if(comprobarFechaRango(fechaActual,fechaInicioMitadSemestre,fechaFinMitadSemestre) == true) {
			//MenuMitadSemestreAlumno();
		}
		else if(comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaCierreSemestre) == false) {
			System.out.println("No hat acciones disponibles");
		}
		else if (fechaActual.getTime()>fechaCierreSemestre.getTime()) {
			System.out.println("Disfrute sus vacaciones");
		}
	}
		
	private void MenuProfesor() {
		SimpleDateFormat fecha = new SimpleDateFormat("dd/MM/YYY");
		System.out.println("Ingrese la fecha actual (dd/MM/YYY): ");
		Date fechaActual = new Date(0);
		System.out.println("La fecha actual es: "+fecha.format(fechaActual));
		Date fechaInicioSemestre = new Date(8/05/2021);
		Date fechaFinInicioSemestre = new Date(2/05/2021);
		Date fechaInicioFinSemestre = new Date(12/07/2021);
		Date fechaFinalFinSemestre = new Date(25/07/2021);
		Date fechaCierreSemestre = new Date(26/07/2021);
		if (comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaFinInicioSemestre) == true) {
			///MenuInicioSemestreProfesor();
		}
		else if(comprobarFechaRango(fechaActual,fechaInicioFinSemestre,fechaFinalFinSemestre) == true) {
			//MenuMitadSemestreAlumno();
		}
		else if(comprobarFechaRango(fechaActual,fechaInicioSemestre,fechaCierreSemestre) == false) {
			System.out.println("No hat acciones disponibles");
		}
		else if (fechaActual.getTime()>fechaCierreSemestre.getTime()) {
			System.out.println("Disfrute sus vacaciones");
		}
	}
	public void inicio_semestre() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Inscribir asignatura Alumno (0) - Eliminar asignatura Alumno (1): ");
		boolean llave = false;
		int opcion = sc.nextInt();
		while(llave=false) {
			if (opcion == 0) {
				llave = true;
				System.out.println("Incribir asignatura");
				System.out.println("Que asignatura desea inscribir?: ");
				String asignatura = sc.nextLine();
				if(verificarExistenciaAsignatura(asignatura)) {
					for(int i=0;i<ListaAsignaturas.getCont();i++) {
						Asignatura a = ListaAsignaturas.getAsignaturaI(i);
						if(a instanceof AsignaturaObligatoria) {
							AsignaturaObligatoria AO = (AsignaturaObligatoria)a;
							System.out.println("Su nivel es: " +AO.getNivel());
							if (ListaEstudiantes.getEstudianteI(i).getNivel() == AO.getNivel()) {
								for(int j=0;j<ListaParalelos.getCont();j++) {
									if (ListaAsignaturas.getAsignaturaI(j).getCodigo().equals(ListaParalelos.getParaleloI(j).getCodigoAsignatura())){
										System.out.println("C"+ListaParalelos.getParaleloI(j).getNumeroParalelo());
									}
								}
								System.out.println("Que paralelo desea inscribir?(Ingrese el n�mero del paralelo): ");
								int numeroParalelo = sc.nextInt();
								if(verificarExistenciaParalelo(numeroParalelo,ListaAsignaturas.getAsignaturaI(i).getCodigo())) {
									System.out.println("Inscribiendo Asignatura");
									ListaEstudiantes.getEstudianteI(i).getAsignaturas().insertarAsignatura(AO);
								}
								else {
									System.out.println("El paralelo no existe");
								}
							}
							else {
								System.out.println("No cumple con los Pre-Requisitos");
							}	
						}
						else if(a instanceof AsignaturaOpcional) {
							AsignaturaOpcional AOP = (AsignaturaOpcional)a;
							if (ListaAsignaturas.getAsignaturaI(i).getCodigo().equals(ListaParalelos.getParaleloI(i).getCodigoAsignatura())){
								System.out.println("Que paralelo desea inscribir?(Ingrese el n�mero del paralelo): ");
								int numeroParalelo = sc.nextInt();
								if(verificarExistenciaParalelo(numeroParalelo,ListaAsignaturas.getAsignaturaI(0).getCodigo())) {
									System.out.println("Inscribiendo Asignatura");
									ListaEstudiantes.getEstudianteI(0).getAsignaturas().insertarAsignatura(AOP);
								}
								else {
									System.out.println("El paralelo no existe");
								}
							}
						}
					}
				}
				else{
					System.out.println("No tienes esa asignatura");
				}
				sc.close();
			}
			else if(opcion == 1) {
				llave = true;
				System.out.println("Eliminar asignatura Alumno:");
				for(int i=0;i<ListaEstudiantes.getEstudianteI(0).getAsignaturas().getCont();i++) {
					System.out.println(ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getNombre()+ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getCodigo());
				}
				System.out.println("Que asignatura desea eliminar?: ");
				String asignatura = sc.nextLine();
				if(verificarExistenciaAsignatura(asignatura)) {
					ListaEstudiantes.getEstudianteI(0).getAsignaturas().eliminar(ListaEstudiantes.getEstudianteI(0).getAsignaturas().buscarPosicion(asignatura));
					System.out.println("Eliminando asignatura");
				}
				else {
					System.out.println("No tienes esa asignatura");
				}
				sc.close();
			}
			
			else {
				llave = false;
				System.out.println("Comando invalido");
			}
		}
	}
	
	@Override
	public void mitad_semestre() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Eliminar asignatura Alumno:");
		for(int i=0;i<ListaEstudiantes.getEstudianteI(0).getAsignaturas().getCont();i++) {
			System.out.println(ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getNombre()+ListaEstudiantes.getEstudianteI(0).getAsignaturas().getAsignaturaI(i).getCodigo());
		}
		System.out.println("Que asignatura desea eliminar?: ");
		String asignatura = sc.nextLine();
		if(verificarExistenciaAsignatura(asignatura)) {
			ListaEstudiantes.getEstudianteI(0).getAsignaturas().eliminar(ListaEstudiantes.getEstudianteI(0).getAsignaturas().buscarPosicion(asignatura));
			System.out.println("Eliminando asignatura");
		}
		else {
			System.out.println("No tienes esa asignatura");
		}
		sc.close();
	}
	@Override
	public void final_semestre() {
		System.out.println("ingresar nota final:");
		for(int i=0;i<ListaProfesores.getProfesorI(0).getAsignaturas().getCont();i++) {
			System.out.println(ListaProfesores.getProfesorI(0).getAsignaturas().getAsignaturaI(i).getNombre()+ListaProfesores.getProfesorI(0).getAsignaturas().getAsignaturaI(i).getCodigo());
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("Que asignatura desea ingresar notas: ");
		String asignatura = sc.nextLine();
		if(verificarExistenciaAsignatura(asignatura)) {
			ListaParalelos.getParaleloI(0).getCodigoAsignatura();
			System.out.println("rut estudiante a colocar nota final: ");
			String nombre = sc.nextLine();
			if(verificarExistenciaAlumno(nombre)) {
				
			}
		}
		else {
			System.out.println("No dicta esa asignatura o no existe");
		}
		sc.close();
	}
	@Override
	public void cierre_semestre() {
		
	}
	public boolean verificarExistenciaAsignatura(String nombre) {
		Asignatura nuevo = ListaAsignaturas.buscarAsignatura(nombre);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	public boolean verificarExistenciaAlumno(String nombre) {
		Estudiante nuevo = ListaEstudiantes.buscarEstudiante(nombre);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	public boolean verificarExistenciaParalelo(int numeroParalelo,String codigoAsignatura) {
		Paralelo p = ListaParalelos.buscarParalelo(numeroParalelo, codigoAsignatura);
		if(p==null) {
			return false;
		}
		else {
			return true;
		}
	}

}
