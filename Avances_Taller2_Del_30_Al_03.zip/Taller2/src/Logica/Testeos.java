package Logica;

public class Testeos {

	public static void main(String[] args) {
	

	}

}
