package Dominio;

import Logica.ListaAsignaturas;

public class Profesor {
	private String rut;
	private String correo;
	private String contrase�a;
	private int salario;
	public ListaAsignaturas asignaturas;
	
	public Profesor(String rut, String correo, String contrase�a, int salario) {
		this.rut = rut;
		this.correo = correo;
		this.contrase�a = contrase�a;
		this.salario = salario;
		asignaturas = new ListaAsignaturas(4);
	}
	
	public ListaAsignaturas getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(ListaAsignaturas asignaturas) {
		this.asignaturas = asignaturas;
	}

	public String getRut() {
		return rut;
	}
	public void setRut(String rut) {
		this.rut = rut;
	}
	public String getContrase�a() {
		return contrase�a;
	}
	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}
	public int getSalario() {
		return salario;
	}
	public void setSalario(int salario) {
		this.salario = salario;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	
}
