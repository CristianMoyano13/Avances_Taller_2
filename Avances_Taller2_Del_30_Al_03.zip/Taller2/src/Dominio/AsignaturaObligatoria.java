package Dominio;

public class AsignaturaObligatoria extends Asignatura {
	private int nivel;
	private String preRequisitos;
	private String codigoPreRequisito;
	
	public AsignaturaObligatoria(String codigo, String nombre, int creditos, String tipo,int nivel, String preRequisitos, String codigoPreRequisito) {
		super(codigo, nombre, creditos, tipo);
		this.nivel = nivel;
		this.preRequisitos = preRequisitos;
		this.codigoPreRequisito = codigoPreRequisito;
	}
	
	public int getNivel() {
		return nivel;
	}
	
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}
	
	public String getPreRequisitos() {
		return preRequisitos;
	}
	
	public void setPreRequisitos(String preRequisitos) {
		this.preRequisitos = preRequisitos;
	}
	
	public String getCodigoPreRequisito() {
		return codigoPreRequisito;
	}
	
	public void setCodigoPreRequisito(String codigoPreRequisito) {
		this.codigoPreRequisito = codigoPreRequisito;
	}
	
	
}
