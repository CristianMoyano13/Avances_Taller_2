package Dominio;

import Logica.ListaAsignaturas;

public class Estudiante {
	private String rutEstudiante;
	private String correo;
	private int nivel;
	private String contrase�a;
	
	public ListaAsignaturas asignaturas;
	
	public Estudiante(String rutEstudiante, String correoEstudiante, int nivelEstudiante,String contrase�aEstudiante) {
		this.rutEstudiante = rutEstudiante;
		this.correo = correoEstudiante;
		this.nivel = nivelEstudiante;
		this.contrase�a = contrase�aEstudiante;
		asignaturas = new ListaAsignaturas(40);
	}
	
	public String getRut() {
		return rutEstudiante;
	}

	public void setRut(String rut) {
		this.rutEstudiante = rut;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public String getContrase�a() {
		return contrase�a;
	}

	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}

	public ListaAsignaturas getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(ListaAsignaturas asignaturas) {
		this.asignaturas = asignaturas;
	}
	
	
}

