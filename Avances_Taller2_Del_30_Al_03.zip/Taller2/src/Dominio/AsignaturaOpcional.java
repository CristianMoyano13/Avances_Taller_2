package Dominio;

public class AsignaturaOpcional extends Asignatura {
	private int creditosMinimos;

	public AsignaturaOpcional(String codigo, String nombre, int creditos, String tipo,int creditosMinimos) {
		super(codigo, nombre, creditos, tipo);
		this.creditosMinimos = creditosMinimos;
	}

	public int getCreditosMinimos() {
		return creditosMinimos;
	}

	public void setCreditosMinimos(int creditosMinimos) {
		this.creditosMinimos = creditosMinimos;
	}
	

	
}
